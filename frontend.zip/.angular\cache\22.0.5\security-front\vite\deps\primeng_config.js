import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-BFYJDFLG.js";
import "./chunk-3AZJ2UCE.js";
import "./chunk-6VCYEF6R.js";
import "./chunk-DVO6TKOM.js";
import "./chunk-7YSP7IBD.js";
import "./chunk-IIKBN4FC.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
